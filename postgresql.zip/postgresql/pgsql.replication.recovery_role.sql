SELECT pg_is_in_recovery()::int
